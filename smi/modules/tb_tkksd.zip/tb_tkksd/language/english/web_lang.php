<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['tb_tkksd'] = 'Kerjasama Tkksd';
$lang['id_tkksd'] = 'ID TKKSD';
$lang['no_tkksd'] = 'Nomor';
$lang['tanggal_tkksd'] = 'Tanggal Kerjasama';
$lang['judul_tkksd'] = 'Judul Kesepakatan (Kerjasama) ';
$lang['kategori_tkksd'] = 'Kategori';
$lang['deskripsi_tkksd'] = 'Deskripsi';
$lang['pihak1'] = 'Pihak 1 (Dalam Kerjasama)';
$lang['pihak2'] = 'Pihak 2 (Dalam Kerjasama)';
$lang['ruang_lingkup'] = 'Ruang Lingkup';
$lang['jangka_wktu_awal'] = 'Jangka Waktu (Awal)';
$lang['jangka_wktu_akhir'] = 'Jangka Waktu (Akhir)';
$lang['pd_pemrakasa'] = 'OPD/PD Pemrakarsa';
$lang['sumber_tkksd'] = 'Sumber';
$lang['dokumen_tkksd'] = ' Lampiran Dokumen (untuk Dipublikasikan)';
$lang['gambar_tkksd'] = 'Lampiran Dokumen (untuk Dipublikasikan)';
$lang['keterangan_lainnya'] = 'Keterangan Lainnya';
$lang['status_tkksd'] = 'Status';
$lang['created_at'] = 'Created At';
